<?php
/**
 * Plugin Name: Strato Helper
 * Description: Un plugin personalizzato per aggiungere widget e funzionalità di supporto.
 * Version: 1.0
 * Author: Il tuo nome o azienda
 */

// Aggiunta del widget sulla dashboard
function strato_helper_dashboard_widget() {
    echo '<div style="text-align: center; padding: 0 10px;">
            <p>Hai bisogno di supporto? Siamo qui per aiutarti.</p>
            <a href="https://stratoagency.com" style="display: block; background-color: #120435; color: white; padding: 10px 20px; text-align: center; text-decoration: none; border-radius: 5px; margin-top: 20px;">Supporto</a>
          </div>';
}

function add_strato_helper_dashboard_widgets() {
    wp_add_dashboard_widget('strato_helper_dashboard_widget', 'Strato Helper', 'strato_helper_dashboard_widget');
}

add_action('wp_dashboard_setup', 'add_strato_helper_dashboard_widgets');

// Aggiunta della voce di menu "Supporto" con icona "help"
function strato_helper_admin_menu() {
    add_menu_page('Supporto', 'Supporto', 'manage_options', 'strato-helper-support', 'strato_helper_support_page', 'dashicons-sos');
}

function strato_helper_support_page() {
    // Includi il file CSS
    echo '<link rel="stylesheet" href="' . plugin_dir_url( __FILE__ ) . 'style.css" type="text/css" />';

    ?>
    <h1>Hai Bisogno di Aiuto?</h1>
    <p>Se hai bisogno di assistenza, compila il form sottostante o <a href="https://stratoagency.com/supporto">clicca qui</a> per aprire un ticket.</p>
    
    <form class="strato-helper-form" action="" method="post" enctype="multipart/form-data">
        <p>
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>
        </p>
        <p>
            <label for="oggetto">Oggetto Richiesta:</label>
            <input type="text" id="oggetto" name="oggetto" required>
        </p>
        <p>
            <label>Urgenza:</label>
            <label><input type="radio" name="urgenza" value="bassa" required> Bassa <span style="color: green;">&#x2690;</span></label>
            <label><input type="radio" name="urgenza" value="media"> Media <span style="color: orange;">&#x2690;</span></label>
            <label><input type="radio" name="urgenza" value="alta"> Alta <span style="color: red;">&#x2690;</span></label>
        </p>
        <p>
            <label for="allegato">Allegato Immagine:</label>
            <input type="file" id="allegato" name="allegato[]" multiple>
        </p>
        <p>
            <label for="messaggio">Messaggio:</label>
            <?php wp_editor('', 'messaggio', array('textarea_name' => 'messaggio', 'media_buttons' => false)); ?>
        </p>
        <p>
            <input type="submit" value="Invia Richiesta">
        </p>
    </form>

    <div class="strato-helper-footer">
        <p>stratospheric plugin, stratospheric support</p>
    </div>
    <?php
}

add_action('admin_menu', 'strato_helper_admin_menu');